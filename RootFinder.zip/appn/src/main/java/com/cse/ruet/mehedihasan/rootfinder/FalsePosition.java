package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Math.pow;

/**
 * Created by Mehedi Hasan on 02-Jun-16.
 */
public class FalsePosition extends Activity {

    EditText a, b, c, d ,e,p, q, er;
    String s = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.false_position_layout);
    }

    private double CalculateFunctionValueOfFalsePosition(double a,double b,double c,double d,double e, double x)
    {
        double y = a * pow(x, 4) + b * pow(x, 3) + c * pow(x, 2) + d * x + e;
        return y;
    }

    public void Calculate_of_false_position(View view) {
        String A, B, C, D, E, P, Q, EE;
        double ca, cb, cc, cd, ce, ap, aq, ee; //coefficients
        a = (EditText) findViewById(R.id.edit_text_for_a_of_false_position);
        b = (EditText) findViewById(R.id.edit_text_for_b_of_false_position);
        c = (EditText) findViewById(R.id.edit_text_for_c_of_false_position);
        d = (EditText) findViewById(R.id.edit_text_for_d_of_false_position);
        e = (EditText) findViewById(R.id.edit_text_for_e_of_false_position);
        p = (EditText) findViewById(R.id.edit_text_for_p_of_false_position);
        q = (EditText) findViewById(R.id.edit_text_for_q_of_false_position);
        er = (EditText) findViewById(R.id.edit_text_for_error_of_false_position);

        A = a.getText().toString();
        B = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        Q = q.getText().toString();
        EE = er.getText().toString();

        ca = Double.parseDouble(A);
        cb = Double.parseDouble(B);
        cc = Double.parseDouble(C);
        cd = Double.parseDouble(D);
        ce = Double.parseDouble(E);
        ap = Double.parseDouble(P);
        aq = Double.parseDouble(Q);
        ee = Double.parseDouble(EE);


        int i = 0;
        double x, x1 = 0.0, diff = 0.0, fx, fp, fq;

        s = s + "n   a             b                x              fx\n";
        while (true) {
            fp = CalculateFunctionValueOfFalsePosition(ca, cb, cc, cd, ce, ap); //calculate f(p)
            fq = CalculateFunctionValueOfFalsePosition(ca, cb, cc, cd, ce, aq); //calculate f(q)
            x = (ap * fq - aq * fp) / (fq - fp);
            if (x > x1)
                diff = x - x1;
            else
                diff = x1 - x;

            if (diff <= ee) {
                s = s +"Root is "+x;
                TextView textView = new TextView(this);
                textView.setText(s);
                textView.setMovementMethod(new ScrollingMovementMethod());
                setContentView(textView);
                break;
            }


            x1 = x;
            fx = CalculateFunctionValueOfFalsePosition(ca, cb, cc, cd, ce, x);


            String AP, AQ, X, FX;
            DecimalFormat df = new DecimalFormat("#.######");
            AP = df.format(ap);
            AQ = df.format(aq);
            X = df.format(x);
            FX = df.format(fx);

            ap = Double.parseDouble(AP);
            aq = Double.parseDouble(AQ);
            x = Double.parseDouble(X);
            fx = Double.parseDouble(FX);

            s = s + "\n"+i;
            s = s + "       "+ap;
            s = s + "       "+aq;
            s = s + "       "+x;
            s = s + "       "+fx;
            s = s + "\n";

            if (fx < 0)
                ap = x;
            else
                aq = x;

            i++;
            fx = 0.0;
            fp = 0.0;
            fq = 0.0;
            diff = 0.0;
        }
    }
}
