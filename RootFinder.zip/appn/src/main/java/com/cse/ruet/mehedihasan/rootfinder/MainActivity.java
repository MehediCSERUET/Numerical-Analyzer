package com.cse.ruet.mehedihasan.rootfinder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void chooseMethod(View view){
        String button_text;
        button_text = ((Button) view).getText().toString();

        if(button_text.equals("Bisection"))
        {
            Intent intent = new Intent(this, Bisection.class);
            startActivity(intent);
        }
        else if(button_text.equals("False Position"))
        {
            Intent intent = new Intent(this, FalsePosition.class);
            startActivity(intent);
        }

        else if(button_text.equals("Newton-Raphson"))
        {
            Intent intent = new Intent(this, NewtonRaphson.class);
            startActivity(intent);
        }
        else if(button_text.equals("Iteration"))
        {
            Intent intent = new Intent(this, Iteration.class);
            startActivity(intent);
        }
        else if(button_text.equals("Secant"))
        {
            Intent intent = new Intent(this, Secant.class);
            startActivity(intent);
        }
        else if(button_text.equals("Ramanujan"))
        {
            Intent intent = new Intent(this, Ramanujan.class);
            startActivity(intent);
        }
        else if(button_text.equals("About")){
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
        }
    }
}
