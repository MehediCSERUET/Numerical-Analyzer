package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by Mehedi Hasan on 23-Jun-16.
 */
public class Splash extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_layout);

        Thread timer = new Thread(){
            public void run(){
                try{
                    sleep(2500);
                }
                catch (InterruptedException e){
                    e.printStackTrace();
                }finally {
                    Intent intent = new Intent("com.cse.ruet.mehedihasan.rootfinder.mainActivity");
                    startActivity(intent);
                    finish();
                }
            }
        };
        timer.start();
    }
}