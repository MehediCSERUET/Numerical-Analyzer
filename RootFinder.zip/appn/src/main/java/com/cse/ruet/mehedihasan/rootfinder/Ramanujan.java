 package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

/**
 * Created by Mehedi Hasan on 02-Jun-16.
 */
public class Ramanujan extends Activity {

    EditText a, b, c, d ,e,p,q, er;
    String s = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ramanujan_layout);
    }

    public void Calculate_of_ramanujan(View view)
    {
        String Aa, Bb, C, D, E,P,Q, EE;
        double A[] = new double[1000];
        double B[] = new double[1000];
        double error, sum, c2, c1, diff;
        int i, j, k, n;
        a = (EditText)findViewById(R.id.edit_text_for_a1_of_ramanujan);
        b =(EditText)findViewById(R.id.edit_text_for_a2_of_ramanujan);
        c =(EditText)findViewById(R.id.edit_text_for_a3_of_ramanujan);
        d =(EditText)findViewById(R.id.edit_text_for_a4_of_ramanujan);
        e =(EditText)findViewById(R.id.edit_text_for_a5_of_ramanujan);
        p =(EditText)findViewById(R.id.edit_text_for_a6_of_ramanujan);
        q = (EditText)findViewById(R.id.edit_text_for_a7_of_ramanujan);
        er = (EditText)findViewById(R.id.edit_text_for_error_of_ramanujan);

        Aa = a.getText().toString();
        Bb = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        Q = q.getText().toString();
        EE = er.getText().toString();

        A[0] = Double.parseDouble(Aa);
        A[1] = Double.parseDouble(Bb);
        A[2] = Double.parseDouble(C);
        A[3] = Double.parseDouble(D);
        A[4] = Double.parseDouble(E);
        A[5] = Double.parseDouble(P);
        A[6] = Double.parseDouble(Q);
        error = Double.parseDouble(EE);

        B[0] = 0.0;
        B[1] = A[0];

        for(i=2;i<1000;i++){
            sum=0;
            for(j=0,k=i-1; (j<=i-1) && (k>=0); j++,k--){
                sum=sum+A[j]*B[k];
                if(sum==0.0)
                    break;
            }
            if(sum==0.0)
                break;
            B[i]=sum;
        }



        i=0; j=1;n=1;
        s = s + "n--------Div1-----------Div2\n";
        while(true)
        {
            c1=B[i++]/B[j++];
            c2=B[i]/B[j];

            String C1, C2;
            DecimalFormat df = new DecimalFormat("#.######");
            C1 = df.format(c1);
            C2 = df.format(c2);

            c1 = Double.parseDouble(C1);
            c2 = Double.parseDouble(C2);

            s = s +""+n;
            s = s + "         "+c1;
            s = s + "         "+c2;
            s = s + "\n";
            n++;
            if(c1>c2)
                diff = c1-c2;
            else
                diff = c2-c1;

            if(diff <= error || c1==c2)
            {
                s = s + "\nSmallest Root "+c2;
                TextView textView = new TextView(this);
                textView.setText(s);
                textView.setMovementMethod(new ScrollingMovementMethod());
                setContentView(textView);
                break;
            }
        }
    }
}
