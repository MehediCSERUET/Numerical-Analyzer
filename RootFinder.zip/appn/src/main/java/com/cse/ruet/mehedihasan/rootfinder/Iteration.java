package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Math.*;

/**
 * Created by Mehedi Hasan on 20-Jun-16.
 */
public class Iteration extends Activity {

    EditText z, b, c, d ,e,p, er;
    String s = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iteration_layout);
    }


    private double calculate1(double x, double a[])
    {
        double m, Y;
        m = -a[0] - a[1] * x - a[2] *  pow(x, 2)- a[3] * pow(x, 3)- a[4] * pow(x, 4)+ a[1] * pow(x, 1);
        Y = pow(m/a[1], 1.00/1.00);
        return Y;
    }
    private double calculate2(double x, double a[])
    {
        double m, Y;
        m = -a[0] - a[1] * x - a[2] *  pow(x, 2)- a[3] * pow(x, 3)- a[4] * pow(x, 4)+ a[2] * pow(x, 2);
        Y = pow(m/a[2], 1.00/2.00);
        return Y;
    }
    private double calculate3(double x, double a[])
    {
        double m, Y;
        m = -a[0] - a[1] * x - a[2] *  pow(x, 2)- a[3] * pow(x, 3)- a[4] * pow(x, 4)+ a[3] * pow(x, 3);
        Y = pow(m/a[3], 1.00/3.00);
        return Y;
    }
    private double calculate4(double x, double a[])
    {
        double m, Y;
        m = -a[0] - a[1] * x - a[2] *  pow(x, 2)- a[3] * pow(x, 3)- a[4] * pow(x, 4)+ a[4] * pow(x, 4);
        Y = pow(m/a[4], 1.00/4.00);
        return Y;
    }

    private void Function(double x, double a[], int choice, double error)
    {
        double Xi=0.0, diff;
        int j=1;
        String A, B, C;
        while(true)
        {
            if(choice==1)
                Xi = calculate1(x, a);
            else if(choice==2)
                Xi = calculate2(x, a);
            else if(choice==3)
                Xi = calculate3(x, a);
            else if(choice==4)
                Xi = calculate4(x, a);

            if(abs(Xi-x)<error)
            {
                s = s + "\n Root is "+Xi;
                TextView textView = new TextView(this);
                textView.setText(s);
                textView.setMovementMethod(new ScrollingMovementMethod());
                setContentView(textView);
                break;
            }

                DecimalFormat df = new DecimalFormat("#.######");
                A = df.format(x);
                B = df.format(Xi);
                C = df.format(abs(Xi-x));
                x = Double.parseDouble(A);
                Xi = Double.parseDouble(B);
                diff = Double.parseDouble(C);

                s = s + ""+j;
                s = s + "     "+x;
                s = s + "     "+Xi;
                s = s + "     "+diff;
                s = s + "\n";
                j++;
                x=Xi;

        }
    }

    public void Calculate_of_iteration(View view)
    {
        String A, B, C, D, E,P, EE;
        double  ap, ee;
        double a[]=new double [5];

        z =(EditText)findViewById(R.id.edit_text_for_a_of_iteration);
        b =(EditText)findViewById(R.id.edit_text_for_b_of_iteration);
        c =(EditText)findViewById(R.id.edit_text_for_c_of_iteration);
        d =(EditText)findViewById(R.id.edit_text_for_d_of_iteration);
        e =(EditText)findViewById(R.id.edit_text_for_e_of_iteration);
        p =(EditText)findViewById(R.id.edit_text_for_p_of_iteration);
        er = (EditText)findViewById(R.id.edit_text_for_error_of_iteration);

        A = z.getText().toString();
        B = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        EE = er.getText().toString();

        a[4] = Double.parseDouble(A);
        a[3] = Double.parseDouble(B);
        a[2] = Double.parseDouble(C);
        a[1] = Double.parseDouble(D);
        a[0] = Double.parseDouble(E);
        ap = Double.parseDouble(P);
        ee = Double.parseDouble(EE);

        s = s + "n---X--------------Xn----------|Xn-x|\n";

        double test[] = new double[3];
        test[0]=ap;
        if(a[1]!=0){
            for(int j=1; j<3; j++)
                test[j]=calculate1(test[j-1], a);
            if(abs(test[2]-test[1])<abs(test[1]-test[0]))
                Function(ap, a, 1, ee);
        }

        if(a[2]!=0){
            for(int j=1; j<3; j++)
                test[j]=calculate2(test[j-1], a);
            if(abs(test[2]-test[1])<abs(test[1]-test[0]))
                Function(ap, a, 2, ee);
        }

        if(a[3]!=0){
            for(int j=1; j<3; j++)
                test[j]=calculate3(test[j-1], a);
            if(abs(test[2]-test[1])<abs(test[1]-test[0]))
                Function(ap, a, 3, ee);
        }

        if(a[4]!=0){
            for(int j=1; j<3; j++)
                test[j]=calculate4(test[j-1], a);
            if(abs(test[2]-test[1])<abs(test[1]-test[0]))
                Function(ap, a, 4, ee);
        }
    }
}