package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Mehedi Hasan on 11-Jul-16.
 */
public class About extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_layout);
    }
}
