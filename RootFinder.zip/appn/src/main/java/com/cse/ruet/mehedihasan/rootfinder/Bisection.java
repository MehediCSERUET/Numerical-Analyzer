package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Math.*;

/**
 * Created by Mehedi Hasan on 02-Jun-16.
 */
public class Bisection extends Activity {

    EditText a, b, c, d ,e,p, q, er;
    String s = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bisection_layout);
    }

    private double CalculateFunctionValueOfBisection(double a,double b,double c,double d,double e, double x)
    {
        double y = a * pow(x, 4) + b * pow(x, 3) + c * pow(x, 2) + d * x + e;
        return y;
    }


    public void Calculate_of_bisection(View view)
    {
        String A, B, C, D, E,P, Q, EE;
        double ca, cb, cc, cd, ce, ap, aq, ee;
        a =(EditText)findViewById(R.id.edit_text_for_a_of_bisection);
        b =(EditText)findViewById(R.id.edit_text_for_b_of_bisection);
        c =(EditText)findViewById(R.id.edit_text_for_c_of_bisection);
        d =(EditText)findViewById(R.id.edit_text_for_d_of_bisection);
        e =(EditText)findViewById(R.id.edit_text_for_e_of_bisection);
        p =(EditText)findViewById(R.id.edit_text_for_p_of_bisection);
        q =(EditText)findViewById(R.id.edit_text_for_q_of_bisection);
        er = (EditText)findViewById(R.id.edit_text_for_error_of_bisection);

        A = a.getText().toString();
        B = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        Q = q.getText().toString();
        EE = er.getText().toString();

        ca = Double.parseDouble(A);
        cb = Double.parseDouble(B);
        cc = Double.parseDouble(C);
        cd = Double.parseDouble(D);
        ce = Double.parseDouble(E);
        ap = Double.parseDouble(P);
        aq = Double.parseDouble(Q);
        ee = Double.parseDouble(EE);




        int i=0;
        double x, x1=0.0, diff=0.0, fx;

        s = s + "n   a         b               x             fx\n";
        while(true) {
            x = (ap + aq) / 2.0;
            if(x>x1)
                diff=x-x1;
            else
                diff=x1-x;

            if (diff <= ee) {
                s = s +"\n Root is "+x;
                TextView textView = new TextView(this);
                textView.setText(s);
                textView.setMovementMethod(new ScrollingMovementMethod());
                setContentView(textView);
                break;
            }

            x1 = x;
            fx = CalculateFunctionValueOfBisection(ca, cb, cc, cd, ce, x);

            String AP, AQ, X, FX;
            DecimalFormat df = new DecimalFormat("#.######");
            AP = df.format(ap);
            AQ = df.format(aq);
            X = df.format(x);
            FX = df.format(fx);

            ap = Double.parseDouble(AP);
            aq = Double.parseDouble(AQ);
            x = Double.parseDouble(X);
            fx = Double.parseDouble(FX);

            s = s + "\n";
            s = s + ""+i;
            s = s + "       "+ap;
            s = s + "       "+aq;
            s = s + "       "+x;
            s = s + "       "+fx;
            s = s + "\n";

            if(fx<0)
                ap=x;
            else
                aq=x;

            i++;
            fx=0;
            diff=0.0;
        }
    }
}
