package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Math.*;

/**
 * Created by Mehedi Hasan on 02-Jun-16.
 */
public class NewtonRaphson extends Activity {

    EditText a, b, c, d ,e,p, er;
    String s = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newton_raphson_layout);
    }


   private double Original(double x, double a, double b, double c, double d, double e)
    {
        double y = a * pow(x, 4) + b * pow(x, 3) + c * pow(x, 2) + d * x + e;
        return y;
    }

    private double Derivative(double x, double a, double b, double c, double d)
    {
        double z = 4 * a * pow(x,3) + 3 * b * x * x + c * x  + d;
        return z;
    }

   private  double Root_of_NR(double x, double a, double b, double c, double d, double e)
    {
        double root = x - (Original(x, a, b, c, d, e)/Derivative(x, a, b, c, d));
        return root;
    }



    public void Calculate_of_NR(View view)
    {
        String A, B, C, D, E,P, EE;
        double ca, cb, cc, cd, ce, ap, ee, x, diff;
        int i=1;
        a =(EditText)findViewById(R.id.edit_text_for_a_of_NR);
        b =(EditText)findViewById(R.id.edit_text_for_b_of_NR);
        c =(EditText)findViewById(R.id.edit_text_for_c_of_NR);
        d =(EditText)findViewById(R.id.edit_text_for_d_of_NR);
        e =(EditText)findViewById(R.id.edit_text_for_e_of_NR);
        p =(EditText)findViewById(R.id.edit_text_for_p_of_NR);
        er = (EditText)findViewById(R.id.edit_text_for_error_of_NR);

        A = a.getText().toString();
        B = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        EE = er.getText().toString();

        ca = Double.parseDouble(A);
        cb = Double.parseDouble(B);
        cc = Double.parseDouble(C);
        cd = Double.parseDouble(D);
        ce = Double.parseDouble(E);
        ap = Double.parseDouble(P);
        ee = Double.parseDouble(EE);

        s = s + "n---------Xn------------------Xn+1\n";

        while(true)
        {
            x = Root_of_NR(ap, ca, cb, cc, cd, ce);
            if(x>ap)
                diff=x-ap;
            else
                diff=ap-x;
            if(diff<=ee)
            {
                s = s + "\n Root is "+x;
                TextView textView = new TextView(this);
                textView.setText(s);
                textView.setMovementMethod(new ScrollingMovementMethod());
                setContentView(textView);
                break;
            }
            else
            {

                String AP,  X;
                DecimalFormat df = new DecimalFormat("#.######");
                AP = df.format(ap);
                X = df.format(x);

                ap = Double.parseDouble(AP);
                x = Double.parseDouble(X);

                s=s+""+i;
                s=s+"     "+ap;
                s=s+"     "+x;
                s=s+"\n";
                ap=x;
            }
            i++;
        }
    }

}
