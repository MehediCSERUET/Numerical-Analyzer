package com.cse.ruet.mehedihasan.rootfinder;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import static java.lang.Math.pow;

/**
 * Created by Mehedi Hasan on 19-Jun-16.
 */
public class Secant extends Activity {

    EditText a, b, c, d ,e,p, q, er;
    String s = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secant_layout);
    }


    private double Function(double a,double b,double c,double d,double e, double x)
    {
        double y = a * pow(x, 4) + b * pow(x, 3) + c * pow(x, 2) + d * x + e;
        return y;
    }

    public void Calculate_of_secant(View view)
    {
        String A, B, C, D, E,P, Q, EE;
        double ca, cb, cc, cd, ce, x1, x2, ee;
        a =(EditText)findViewById(R.id.edit_text_for_a_of_secant);
        b =(EditText)findViewById(R.id.edit_text_for_b_of_secant);
        c =(EditText)findViewById(R.id.edit_text_for_c_of_secant);
        d =(EditText)findViewById(R.id.edit_text_for_d_of_secant);
        e =(EditText)findViewById(R.id.edit_text_for_e_of_secant);
        p =(EditText)findViewById(R.id.edit_text_for_p_of_secant);
        q =(EditText)findViewById(R.id.edit_text_for_q_of_secant);
        er = (EditText)findViewById(R.id.edit_text_for_error_of_secant);

        A = a.getText().toString();
        B = b.getText().toString();
        C = c.getText().toString();
        D = d.getText().toString();
        E = e.getText().toString();
        P = p.getText().toString();
        Q = q.getText().toString();
        EE = er.getText().toString();

        ca = Double.parseDouble(A);
        cb = Double.parseDouble(B);
        cc = Double.parseDouble(C);
        cd = Double.parseDouble(D);
        ce = Double.parseDouble(E);
        x1 = Double.parseDouble(P);
        x2 = Double.parseDouble(Q);
        ee = Double.parseDouble(EE);


        double f1, f2, X, t;
        String AP, AQ, XX, F1, F2;
        int i=1;

        s = s + "n   a   b    x     f(a)    f(b)\n";
        do
        {
            f1=Function(ca, cb, cc, cd, ce, x1);
            f2=Function(ca, cb, cc, cd, ce, x2);
            X=x2-((f2*(x2-x1))/(f2-f1));

            DecimalFormat df = new DecimalFormat("#.######");
            AP = df.format(x1);
            AQ = df.format(x2);
            XX = df.format(X);
            F1 = df.format(f1);
            F2 = df.format(f2);

            x1 = Double.parseDouble(AP);
            x2 = Double.parseDouble(AQ);
            X = Double.parseDouble(XX);
            f1 = Double.parseDouble(F1);
            f2 = Double.parseDouble(F2);

            s = s + ""+i;
            s = s + "   "+x1;
            s = s + "   "+x2;
            s = s + "   "+X;
            s = s + "   "+f1;
            s = s + "   "+f2;
            s = s + "\n";
            i++;

            x1=x2;
            x2=X;

            if(f2<0)
                t = f2 * -1.0;
            else
                t = f2;

        }while(t>ee);

        s = s +"\n Root is "+X;
        TextView textView = new TextView(this);
        textView.setText(s);
        textView.setMovementMethod(new ScrollingMovementMethod());
        setContentView(textView);
    }
}
